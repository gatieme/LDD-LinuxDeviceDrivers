#ifndef _MULTI_DIV_H
#define _MULTI_DIV_H

extern long multiply_test(long a,long b);
extern long divide_test(long a,long b);

#endif