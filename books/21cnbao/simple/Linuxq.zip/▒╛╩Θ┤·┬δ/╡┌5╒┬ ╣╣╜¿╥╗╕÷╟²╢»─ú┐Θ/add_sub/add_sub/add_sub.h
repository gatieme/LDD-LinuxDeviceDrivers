/****************************************
* add_sub.h                               *
*****************************************/
#ifndef _ADD_SUB_H_
#define _ADD_SUB_H_

long add_integer(long a, long b);
long sub_integer(long a, long b);

#endif
